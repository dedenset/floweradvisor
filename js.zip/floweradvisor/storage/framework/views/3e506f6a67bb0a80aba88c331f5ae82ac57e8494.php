<div id="fl_modal" class="modal fade guest-log" role="dialog">
<div class="modal-dialog">
<div class="modal-content main-mod loginbox-content">
</div>
</div>
</div>


<div id="nl_modal" class="modal fade main-login" role="dialog">
<div class="modal-dialog">
<div class="modal-content normal-loginbox">
</div>
</div>
</div>


<div id="gl_modal" class="modal fade main-login" role="dialog">
<div class="modal-dialog">
<div class="modal-content guest-loginbox">
</div>
</div>
</div>


<div id="sl_modal" class="modal fade main-login" role="dialog">
<div class="modal-dialog">
<div class="modal-content signup-box">
</div>
</div>
</div>


<div id="login_modal" class="modal fade" role="dialog">
<div class="mini-modal">
<div class="modal-content main-mod loginbox-content">
</div>
</div>
</div>


<div id="g2_modal" class="modal fade main-login" role="dialog">
<div class="mini-modal">
<div class="modal-content guest-loginbox">
</div>
</div>
</div>


<div id="s2_modal" class="modal fade main-login" role="dialog">
<div class="mini-modal">
<div class="modal-content signup-box">
</div>
</div>
</div>
<?php /**PATH D:\xampp\htdocs\floweradvisor\floweradvisor\resources\views/modal.blade.php ENDPATH**/ ?>