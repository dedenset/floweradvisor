<!-- Dialog -->
<div id="errorDialog" class="modal fade main-login" role="dialog">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-body clearfix">
<button type="button" class="close" data-dismiss="modal">&times;</button>
<span id="errorMsg"></span>
</div>
</div>
</div>
</div>

<div id="ConnDialog" class="modal fade main-login" role="dialog">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-body clearfix">
<button type="button" class="close" data-dismiss="modal">&times;</button>
<span id="ConnMsg"></span>
</div>
</div>
</div>
</div>

<div id="successDialog" class="modal fade main-login" role="dialog">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-body clearfix">
<button type="button" class="close" data-dismiss="modal">&times;</button>
<span id="successMsg"></span>
</div>
</div>
</div>
</div>
<!-- Dialog -->
<?php /**PATH D:\xampp\htdocs\floweradvisor\floweradvisor\resources\views/dialog.blade.php ENDPATH**/ ?>