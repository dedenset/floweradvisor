</body>
</html><?php /**PATH D:\xampp\htdocs\floweradvisor\floweradvisor\resources\views/footer.blade.php ENDPATH**/ ?>