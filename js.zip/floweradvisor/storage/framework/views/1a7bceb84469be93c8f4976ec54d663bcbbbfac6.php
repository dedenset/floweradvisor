<?php $__env->startSection('content-wrapper'); ?>
<div class="content2 cart-main">
<span class="cart-body-cont">
<div class="cart-container">
 <div class="row">
    <div class="col-md-12 mb-5">
        <center>
        <h1>Troli Anda</h1>
        </center>
    </div>
 </div>
 

<!--
<div class="notice">
<div class="success-code hidden">
<p>Sedang memperbaharui troli, mohon tunggu...</p>
</div>
<div class="success-code success-code1 hidden">
<p>Berhasil memasukkan kode promo</p>
</div>
<div class="failed-code hidden">
<p>Maaf! kode promo yang anda masukkan tidak valid</p>
</div>
</div>
-->

<div class="cart-table">
<div class="cart-header">
<div class="cart-filler"> </div>
<div class="c-prod">Produk</div>
<div class="c-price">Pilih Harga</div>
<div class="c-qty">Kuantitas</div>
<div class="c-subtot">Subtotal</div>
<div class="c-remove">Hapus</div>
</div>

<?php $__currentLoopData = $troli_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $td): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="cart-content cart-<?php echo e($td->produk_kode); ?>">
<div class="cart-img">
<a href="#"><img src="<?php echo e($td->gambar); ?>"></a>
</div>
<div class="c-prod">
<span class="b-name"><a href="#"><?php echo e($td->produk); ?></a></span>
<span class="b-id"><?php echo e($td->produk_kode); ?></span>
 <span class="b-id crimson"></span>
</div>
<div class="c-price">
<span class="b-price">
Rp <?php echo e(number_format($td->harga)); ?>

</span>
</div>
<div class="c-qty">
<div class="main-cart-qty">
<div class="add-min">
<a class="up" data-code="<?php echo e($td->id); ?>"><i class="fa fa-chevron-up qty-up" style="cursor:pointer;"></i></a>
<form method="post" id="up<?php echo e($td->id); ?>" action="<?php echo e(url('/'.$td->id )); ?>"/>
    <?php echo csrf_field(); ?>
    <input  type="hidden" name="tipe" value="up">
    <input  type="hidden" name="qty" value="1">
</form>

<a class="down" data-code="<?php echo e($td->id); ?>"><i class="fa fa-chevron-down qty-down" style="cursor:pointer;"></i></a>
<form method="post" id="down<?php echo e($td->id); ?>" action="<?php echo e(url('/'.$td->id )); ?>"/>
    <?php echo csrf_field(); ?>
    <input  type="hidden" name="tipe" value="down">
    <input  type="hidden" name="qty" value="1">
</form>
</div>
    <input type="text" data-code="<?php echo e($td->produk_kode); ?>" class="c-i-qty" value="<?php echo e($td->qty); ?>" inum="qty<?php echo e($td->id); ?>">
</div>
</div>
<div class="c-subtot">
<span class="b-price subtotal-FA4532">Rp <?php echo e(number_format($td->subtotal)); ?></span>
</div>
<div class="c-remove">
<span class="cart-remove">
<a><i class="fa fa-times del" style="cursor:pointer;" data-id="<?php echo e($td->id); ?>"></i></a>
<form method="post" id="del<?php echo e($td->id); ?>" action="<?php echo e(url('/'.$td->id )); ?>"/>
    <?php echo csrf_field(); ?>
    <input type="hidden" name="_method" value="DELETE"/>
    <input  type="hidden" name="tipe" value="down">
    <input  type="hidden" name="qty" value="1">
</form>

</span>
</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="row discount-row" align="left">
<div class="col-md-7 col-xs-7"></div>
<div class="col-md-5 col-xs-5">
<a href="#" class="discount-text" data-toggle="modal" data-target="#exampleModal">
    <img src="https://img.floweradvisor.com/images/discount-ico.png">
    <span class='text btnDisc'> Gunakan Kode Diskon/Reward</span>
</a>
</div>
</div>

<?php if(!empty($trolis->tipe_discount)): ?>

<div class="cart-result dashtop1-black">
<div class="result-filler"></div>
<div class="c-sub">
    <span class="result-sub pull-left">Sub Total</span>
</div>
<div class="c-subtot">
    <span class="c-total">Rp <?php echo e(number_format($trolis->subtotal)); ?></span>
</div>
</div>

<div class="cart-result">
<div class="result-filler"></div>
<div class="c-sub">
    <span class="result-sub pull-left">Discount <?php echo e($discTipe); ?></span>
</div>
<div class="c-subtot">
    <span class="c-total">
        <?php if($trolis->tipe_discount == 'fixed'): ?>
            Rp -<?php echo e(number_format($trolis->discount)); ?>

        <?php else: ?>
            <?php echo e($discTotalView); ?>

        <?php endif; ?>
    </span>
</div>
<div class="result-filler2"></div>
</div>
<?php endif; ?>


<div class="cart-result dashtop1-black">
<div class="result-filler"></div>
<div class="c-sub">
<span class="result-sub pull-left">Total</span>
</div>
<div class="c-subtot">
<span class="c-total">Rp <?php echo e(number_format($trolis->total)); ?></span>
</div>
<div class="result-filler2"></div>
</div>

<div class="cart-result dashtop1-black"></div>


</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('troli-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\floweradvisor\floweradvisor\resources\views/troli.blade.php ENDPATH**/ ?>