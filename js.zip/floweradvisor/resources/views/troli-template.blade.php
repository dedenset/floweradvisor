@include('header')
@include('sweet::alert')
<div class="content">
<div class="wrapper">
 @yield('content-wrapper')
</div>
</div>
@include('dialogdiscount')
@include('footer')